import "./App.css";
import { useState } from "react";
import TimerComponent from "./components/TimerComponent";
import MultiEffectComponent from "./components/MultiEffectComponent";

function App() {
  const [count, setCount] = useState(0);
  const [total, setTotal] = useState(1);

  // first ---> side-effect function
  // second ---> clean-up function
  // third ---> comma seperated dependency list

  // Variation 1:
  // runs on every render

  // useEffect(() => {
  //   alert("I will run on each render");
  // });

  // Variation 2:
  // that runs on only first render

  // useEffect(() => {
  //   alert("I will run only on first render");
  // }, []);

  // Variation 3:
  // runs when depencency list updated

  // useEffect(() => {
  //   alert("I will run every time when count is updated");
  // }, [count]);

  // Variation 4:
  // multiple dependencies

  // useEffect(() => {
  //   alert("I will run every time when count or total is updated");
  // }, [count, total]);

  // function handleClickCount() {
  //   setCount(count + 1);
  // }

  // function handleClickTotal() {
  //   setTotal(total + 1);
  // }

  // Variation 5:
  // clean-up function

  // useEffect(() => {
  //   alert("Count is updated");
  //   return () => {
  //     alert("Count is unmounted from UI");
  //   };
  // }, [count]);

  return (
    // <div>
    //   <button onClick={handleClickCount}>Update count</button>
    //   <br />
    //   Count is: {count}
    //   <br />
    //   <button onClick={handleClickTotal}>Update total</button>
    //   <br />
    //   Total is: {total}
    // </div>
    <>
      {/* <TimerComponent /> */}
      <MultiEffectComponent />
    </>
  );
}

export default App;
