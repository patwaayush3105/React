import "./App.css";
import { useState } from "react";
import Card from "./components/Card";
import Buttons from "./components/Buttons";

function App() {
  const [count, setCount] = useState(0);

  function handleClick() {
    setCount(count + 1);
  }

  return (
    <div>
      <Buttons incrementCount={handleClick} text="Click me">
        <h1>{count}</h1>
      </Buttons>

      {/* <Card name="Ayush">
        <h1>Best WEB DEVELOPMENT course</h1>
        <p>You have to join this</p>
      </Card> */}
    </div>
  );
}

export default App;
