import React from "react";
import { useNavigate } from "react-router-dom";
const About = () => {
  const navigate = useNavigate();

  function handleClick() {
    navigate("/dashboard");
  }
  return (
    <div>
      <button onClick={handleClick}>Move to Dashboard Page</button>About Page
    </div>
  );
};

export default About;
