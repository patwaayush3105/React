import "./App.css";

function App() {
  function handleClick() {
    alert("Button clicked!");
  }
  function handleMouseOver() {
    alert("Mouse over!");
  }

  function handleOnChange(e) {
    // console.log("Change");
    console.log(e.target.value);
  }

  function handleSubmit(e) {
    e.preventDefault();
    // I am writing my custom behaviour down
    alert("Submit");
  }

  return (
    <div>
      {/* <p onMouseOver={handleMouseOver}>This is a paragraph</p>
      <button onClick={handleClick}>Click me</button> */}

      {/* <form onSubmit={handleSubmit}>
        <input type="text" onChange={handleOnChange} />
        <button type="submit">Submit</button>
      </form> */}

      {/* Always pass the reference of function rather than pass it immediately */}
      <button onClick={() => alert("Button clicked!")}>Click me</button>
    </div>
  );
}

export default App;
