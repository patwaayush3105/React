import { useState } from "react";
import Card from "./components/Card";
import "./App.css";

function App() {
  // create state
  // manage state
  // change state

  const [name, setName] = useState("");

  return (
    <div>
      <Card title="Card1" name={name} setName={setName}></Card>
      <Card title="Card2" name={name} setName={setName}></Card>

      {/* <p>Inside Parent Component: {name}</p> */}
    </div>
  );
}

export default App;
